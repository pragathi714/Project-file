import mongoose from 'mongoose';

const BookSchema = new mongoose.Schema({
  title: { type: String, required: true },
  author: { type: String, required: true },
  genre: { type: String, required: true },
  description: { type: String },
  price: { type: Number, required: true },
  quantity: { type: Number, required: true },
  image: { type: String }, // URL or filename for book image
  seller: {type: mongoose.Schema.Types.ObjectId,ref:'User',required: true}
}, { timestamps: true });

const Book = mongoose.model('Book', BookSchema);
export default Book;
