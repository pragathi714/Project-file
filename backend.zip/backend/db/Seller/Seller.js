import mongoose from 'mongoose';

const SellerSchema = new mongoose.Schema({
  username: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  // You can add fields like 'storeName', 'products', etc. if needed
});

const Seller = mongoose.model('sellers', SellerSchema);
export default Seller;
