import mongoose from 'mongoose';

const WishlistSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'users', required: true },
  books: [{ type: mongoose.Schema.Types.ObjectId, ref: 'books' }],
});

const Wishlist = mongoose.model('wishlists', WishlistSchema);
export default Wishlist;
