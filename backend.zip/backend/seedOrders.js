// backend/db/seedOrders.js
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Order from './Orders/Order.js';
import User from './Users/User.js';
import Book from './Books/Book.js';
import connectDB from '../config.js';

dotenv.config();
await connectDB();

const seedOrders = async () => {
  try {
    const buyer = await User.findOne({ role: 'user' });
    const seller = await User.findOne({ role: 'seller' });
    const book = await Book.findOne({ seller: seller._id });

    if (!buyer || !seller || !book) {
      console.log('❌ Missing buyer/seller/book. Check your DB.');
      return process.exit(1);
    }

    const orders = [
      {
        user: buyer._id,
        books: [{ book: book._id, quantity: 1 }],
        totalPrice: book.price,
        status: 'pending',
      },
      {
        user: buyer._id,
        books: [{ book: book._id, quantity: 2 }],
        totalPrice: book.price * 2,
        status: 'shipped',
      },
    ];

    await Order.deleteMany();
    await Order.insertMany(orders);
    console.log('✅ Dummy orders inserted!');
    process.exit();
  } catch (error) {
    console.error('❌ Seeding failed:', error);
    process.exit(1);
  }
};

seedOrders();
