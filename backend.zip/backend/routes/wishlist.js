import express from 'express';
import Wishlist from '../db/Wishlists/Wishlist.js';
import authMiddleware from '../middleware/authMiddleware.js';

const router = express.Router();

// ✅ Get the current user's wishlist
router.get('/', authMiddleware, async (req, res) => {
  try {
    const wishlist = await Wishlist.findOne({ user: req.user.userId }).populate('books');
    res.json(wishlist ? wishlist.books : []);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ✅ Add a book to wishlist
router.post('/:bookId', authMiddleware, async (req, res) => {
  try {
    let wishlist = await Wishlist.findOne({ user: req.user.userId });
    if (!wishlist) {
      wishlist = new Wishlist({ user: req.user.userId, books: [] });
    }
    if (!wishlist.books.includes(req.params.bookId)) {
      wishlist.books.push(req.params.bookId);
      await wishlist.save();
    }
    res.json(wishlist);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ✅ Remove a book from wishlist
router.delete('/:bookId', authMiddleware, async (req, res) => {
  try {
    const wishlist = await Wishlist.findOne({ user: req.user.userId });
    if (wishlist) {
      wishlist.books = wishlist.books.filter(
        (bookId) => bookId.toString() !== req.params.bookId
      );
      await wishlist.save();
      res.json(wishlist);
    } else {
      res.status(404).json({ error: 'Wishlist not found' });
    }
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
