import express from 'express';
import User from '../db/Users/User.js';
import Order from '../db/Orders/Order.js';
import Seller from '../db/Seller/Seller.js';

const router = express.Router();

// GET all users
router.get('/users', async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET all orders
router.get('/orders', async (req, res) => {
  try {
    const orders = await Order.find().populate('user books'); // adjust as needed
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET all sellers
router.get('/sellers', async (req, res) => {
  try {
    const sellers = await Seller.find();
    res.json(sellers);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
// GET orders by user ID
router.get('/user-orders/:userId', async (req, res) => {
  const { userId } = req.params;
  try {
    const orders = await Order.find({ user: userId })
      .populate('books.book', 'title image')
      .populate('user', 'username email');
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch user orders' });
  }
});

export default router;
