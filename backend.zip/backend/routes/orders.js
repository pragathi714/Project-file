// ✅ Updated Seller Orders Route
// backend/routes/orders.js

import express from 'express';
import Order from '../db/Orders/Order.js';
import Book from '../db/Books/Book.js';
import authMiddleware from '../middleware/authMiddleware.js';

const router = express.Router();

// POST: Create a new order
router.post('/', authMiddleware, async (req, res) => {
  const { books, totalPrice } = req.body;

  try {
    const userId = req.user.userId || req.user._id;

    const newOrder = new Order({
      user: userId,
      books,
      totalPrice,
    });

    await newOrder.save();
    res.status(201).json(newOrder);
  } catch (err) {
    console.error('Error creating order:', err);
    res.status(400).json({ error: 'Failed to create order' });
  }
});

// GET: Fetch seller's orders
router.get('/seller', authMiddleware, async (req, res) => {
  try {
    const userId = req.user.userId || req.user._id;

    const sellerBooks = await Book.find({ seller: userId });
    const sellerBookIds = sellerBooks.map(b => b._id);

    const orders = await Order.find({ 'books.book': { $in: sellerBookIds } })
      .populate('user', 'name email')
      .populate('books.book', 'title image');

    res.json(orders);
  } catch (err) {
    console.error('Error fetching seller orders:', err);
    res.status(500).json({ error: 'Failed to fetch seller orders' });
  }
});

export default router;
