import express from 'express';
import Book from '../db/Books/Book.js';

const router = express.Router();

// Get all books
router.get('/', async (req, res) => {
  try {
    const books = await Book.find();
    res.json(books);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add a new book
router.post('/', async (req, res) => {
  const { title, author, genre, description, price, quantity, image } = req.body;
  try {
    const newBook = new Book({ title, author, genre, description, price, quantity, image });
    await newBook.save();
    res.status(201).json(newBook);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
router.delete('/:id', async (req, res) => {
  try {
    const deletedBook = await Book.findByIdAndDelete(req.params.id);
    if (!deletedBook) {
      return res.status(404).json({ error: 'Book not found.' });
    }
    res.json({ message: 'Book deleted successfully.' });
  } catch (error) {
    console.error('Failed to delete book:', error);
    res.status(500).json({ error: 'Server error.' });
  }
});

export default router;
